from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Chrome()
driver.set_window_size(1120, 550)

def loguearse(usuario, contra):
	user = driver.find_element_by_name("username")
	user.send_keys(usuario)

	password = driver.find_element_by_name("password")
	password.send_keys(contra)
	password.send_keys(Keys.RETURN)
	driver.implicitly_wait(5)


def obtener_numero(xpath):
	return int(driver.find_element_by_xpath(xpath).text) 

def clickear(xpath):
	poronga = driver.find_element_by_xpath(xpath)
	poronga.click()
	driver.implicitly_wait(5)

def scroll_infinito(xpath_dialog, total):
	USERS_POR_SCROLL = 12 #---------------------------------------------------------------------------
	ITER_ERROR = 3

	dialog = driver.find_element_by_xpath(xpath_dialog)

	i = 1
	iter_totales = round(total / USERS_POR_SCROLL) + ITER_ERROR
	promedio_por_carga = 0
	SCROLL_PAUSE_TIME = 0.7
	old_src = driver.page_source
	#scroll down the page
	while True:

		t1 = time.time()
		# Scroll down to bottom
		driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", dialog)
		time.sleep(SCROLL_PAUSE_TIME)
		t2 = time.time()
		delta = t2 - t1

		promedio_por_carga = round(((promedio_por_carga*(i-1)) + delta) / i, 2)

		porcentaje = round((((i+1)/iter_totales))*100, 2)
		iter_restantes = (iter_totales - i - 1)
		print("Cargando usuarios, {:.2f}% completado. Tiempo restante estimado: {:.2f} segundos".format(porcentaje, promedio_por_carga*iter_restantes))

		if driver.page_source == old_src:
			break

		old_src = driver.page_source

		i += 1


def cargar_y_guardar(xpath_click, xpath_dialog, file_name, user_check):
	clickear(xpath_click)

	time.sleep(1)

	scroll_infinito(xpath_dialog, user_check)
	print("Todos los usuarios cargados, extrayendo datos.\n")

	DATA = driver.find_element_by_xpath(xpath_dialog + "/ul").text.splitlines()

	aux = [DATA[i] for i in range(1,len(DATA)) if DATA[i-1] in ["Seguir","Siguiendo"]]
	DATA = [DATA[0]] + aux

	print("Cargados: {}".format(len(DATA)))
	#print(DATA)
	assert len(DATA) == user_check
	assert "Siguiendo" not in DATA
	assert "Seguir" not in DATA

	with open(file_name, "w", encoding="ISO-8859-1") as archivo:
		archivo.write(str(DATA))

	clickear('/html/body/div[3]/div/div/div[1]/div[2]/button')
	

def scrap(USERNAME, PSWD, FILENAME_FOLLOWERS, FILENAME_FOLLOWING):

	driver.get("https://www.instagram.com/accounts/login/")

	loguearse(USERNAME, PSWD)

	clickear('/html/body/div[3]/div/div/div/div[3]/button[2]') #boton poronga

	clickear('//*[@id="react-root"]/section/nav/div[2]/div/div/div[3]/div/div[3]/a') #profile

	allfollowers = obtener_numero('//*[@id="react-root"]/section/main/div/header/section/ul/li[2]/a/span')

	allfollowing = obtener_numero('//*[@id="react-root"]/section/main/div/header/section/ul/li[3]/a/span')

	print(allfollowers, " - ", allfollowing)

	print("PROCESANDO FOLLOWERS")
	cargar_y_guardar('//*[@id="react-root"]/section/main/div/header/section/ul/li[2]/a', '/html/body/div[3]/div/div/div[2]', FILENAME_FOLLOWERS, allfollowers)

	print("PROCESANDO FOLLOWING")
	cargar_y_guardar('//*[@id="react-root"]/section/main/div/header/section/ul/li[3]/a', '/html/body/div[3]/div/div/div[2]', FILENAME_FOLLOWING, allfollowing)

	driver.close()



if __name__ == "__main__":

	scrap("user", "password", "DATA5_followers.txt", "DATA5_following.txt")