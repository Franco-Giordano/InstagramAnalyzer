import scrapper


WHITELIST = []
try:
	import WHITELIST
except ModuleNotFoundError:
	print("Ninguna Whitelist definida, ignorando...")



def parseDatosUsuario():
      with open(r'C:\Users\gamer\Documents\GitHub\InstagamScrapper\users.txt') as arch:
            return arch.readlines()[0].split(", ")


def obtenerUsers(ruta):
      with open(ruta, encoding="ISO-8859-1") as archivox:
            return set(eval(archivox.readline())) - set(WHITELIST.WHITELIST)

def estaEnWhitelist(elemento):
    return elemento in WHITELIST

USUARIO, PASS = parseDatosUsuario()
NUMERO_ITERACION = "6"

scrapper.scrap(USUARIO, PASS, "DATA" + NUMERO_ITERACION + "_followers.txt", "DATA" + NUMERO_ITERACION + "_following.txt")

followers = obtenerUsers(r'C:\Users\gamer\Documents\GitHub\InstagamScrapper\DATA' + NUMERO_ITERACION + '_followers.txt')
following = obtenerUsers(r'C:\Users\gamer\Documents\GitHub\InstagamScrapper\DATA' + NUMERO_ITERACION + '_following.txt')

unfollowers = list(following - followers)
fans = list(followers - following)




print("-----------------UNFOLLOWERS-----------------")
for user in unfollowers:
      print(user)
print("-----------------", len(unfollowers), "-----------------")

if (len(unfollowers) == 0):
    print("    :D    ")


print("-----------------FANS-----------------")
for f in fans:
      print(f)
print("-----------------", len(fans), "-----------------")
